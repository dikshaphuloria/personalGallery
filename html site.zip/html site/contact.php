
<?php

session_start();

if(!isset($_SESSION['Username'])){

	$_SESSION['msg'] = "You must log in to view this page";
	header('location: login.php');

}

if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION["Username"]);
	header("location: index.html");
}


?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>~ Contact Us ~</title>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body >

	<div class="contact">
				
		<?php if(isset($_SESSION['Username'])): ?>
				<h2>Any quaries <?php echo $_SESSION['Username']; ?> ?</h1>
		<?php endif?>
				

		<div class="logos">
					
			<h3 style="font-size: 25px;">&#128222; +91 9703425452</h3>
			<h3 style="font-size: 25px;">&#9993; dikshaphuloria@gmail.com </h3>
					
			<h3>Follow Us:</h3>
			<a href="https://www.linkedin.com/in/diksha-phuloria-b4a0ab192"><img src="images/logos/download.png"></a>
			<a href="https://www.instagram.com/diksha.phuloria"><img src="images/logos/instagram.png"></a>
			<a href="https://github.com/dikshaphuloria"><img src="images/logos/gt.png"></a>
								
		</div>

		</div>
<div class="hello" style="background-color: transparent;">
		<a href="main.php" >&#9754; Return To Gallery</a>
</div>

</body>
<script src="first.js"></script>
<style>
	body{
		animation: sp1 5s infinite alternate;
		justify-content: center;
		align-items: center; 
		align-content: center;

	}

	a{	
		font-size: 25px;
		text-decoration: none;
		cursor: pointer;
		background: black;
		color: white;
		padding: 10px;
	}

	a:hover{
		background: #eee234;
		color: black;

	}

	.contact{
		width: 500px;
		height: auto;
		margin:70px auto;
		padding: 20px 20px 20px 20px;
		border: 1px solid #BFBFBF;
		background-color: #ccc;
		font-size: 25px;
		font-weight: 1000;
		text-align: center;

	}


	@keyframes sp1{
	0%{background:#EFBE93; }
    25%{background:#FC766AFF;}
    50%{background: #783937FF;}
    75%{background:#184A45FF;}
    100%{background:black;}
} 


</style>
</html>