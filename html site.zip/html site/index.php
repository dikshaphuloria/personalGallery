<?php

session_start();

if(!isset($_SESSION['Username'])){

	$_SESSION['msg'] = "You must log in to view this page";
	header('location: login.php');

}

if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION["Username"]);
	header("location: index.html");
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">

	<style>
		body{
			background-image: url(images/pic2.jpeg);
			background-size: cover;
			justify-content: center;
			font-family: Times;
		}
	</style>

</head>
<body>

	<?php if(isset($_SESSION['success'])): ?>

		<div class="error success">
			<h3>
				<?php 

				echo $_SESSION['success'];
				unset($_SESSION['success']);

				?>
			</h3>
		</div>

	<?php endif?>

<!-- logged in user information -->


<div class="hello">
	<div style="font-size: 40px; margin-top:50px;">HELLO !</div>

	<?php if(isset($_SESSION['Username'])): ?>
		<h1 style="font-family:'Tangerine'; font-weight: 100; ">Welcome <?php echo $_SESSION['Username']; ?></h1>

		<button class="logout"><a href="index.php?logout='1'">&#8592;Logout</a></button>

	<?php endif?>


	<a href="main.html" >Let's Proceed &#8594;</a>
</div>

</body>
</html>