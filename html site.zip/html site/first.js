//To highlight the nav tag

function openNav() {
  	document.getElementById("myNav").style.width = "100%";
}

function closeNav() {
  	document.getElementById("myNav").style.width = "0%";
}



/*To darken the image while hovering, it will showcase the name of the artist*/

const portfolioItems = document.querySelectorAll('.portfolio-item-wrapper')

	portfolioItems.forEach(portfolioItem =>{
		portfolioItem.addEventListener('mouseover',()=>{
			console.log(portfolioItem.childNodes[1].classList);
			portfolioItem.childNodes[1].classList.add('img-darken');
		})

		portfolioItem.addEventListener('mouseout',()=>{
			portfolioItem.childNodes[1].classList.remove('img-darken');
		})
	})


/*To show the current date and time*/

	function startTime() {
	  var today = new Date();
	  var h = today.getHours();
	  var m = today.getMinutes();
	  var s = today.getSeconds();
	  m = checkTime(m);
	  s = checkTime(s);
	  
	  document.getElementById('time').innerHTML =
	  h + ":" + m + ":" + s;
	  var t = setTimeout(startTime, 500);

	  document.getElementById('date').innerHTML= today.toDateString();

	}



	function checkTime(i) {
	  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
	  return i;
	}


//Home Portfolio toggle button
	
	$(document).ready(function() {
		$("#gal").on('click',function(event) {
			$(".portfolio-item-wrapper").fadeToggle("fast");
			$(".content-wrap2").fadeToggle("fast");
			$("#tap").fadeToggle("slow");
		});	
		
	});


