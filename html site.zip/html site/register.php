<?php error_reporting(0);?>
<?php include('server.php'); ?>


<!DOCTYPE html>
<html>
<head>
	<title>~ Welcome ~</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="styles.css">
	
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">

	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

	<script src="first.js"></script>




</head>
<body>

	<div class="container">
		
		<div id="myNav" class="overlay">
  			<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		  	<div class="overlay-content">
		    	<a href="index.html">HOME</a>
		    	<a href="about.html">ABOUT</a>
		    	<a href="feedback.php">FEEDBACK</a>
		    	<a href="register.php">Currently In Registering Process</a>
		  	</div>
		</div>
		<div class="nav" onclick="openNav()">&#8801;</div>

     		

		<div class="block1">
			
			<div class="sub1">

				<div class="welcome1">  R E G I S T E R  </div>

				<div class="form-box1">
					<div class="button-box1">
						<div id="btn1" style="left: 110px;"></div>
						<button type="button" class="toggle-btn1" ><a href="login.php">Login</a></button>

						<button type="button" class="toggle-btn1" >Register</button>

					</div>

					<form id="register" class="form2" action="register.php" method="post">
						<?php include('errors.php'); ?>
						

						<input type="text" class="input-field1" name="Username" placeholder="Username" required>

						<input type="email" class="input-field1" name="email" placeholder="Email ID" pattern="^[a-zA-Z0-9]+(\.[_a-zA-Z0-9]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,15})$" title="Email must follow the valid format as name@gmail/yahoo.com" required>

						<input type="password" class="input-field1 userInput"  id="password" name="password1" placeholder="Enter Password"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"  required>

						<input type="password" class="input-field1 userInput" id="confirm_password" name="password2" placeholder="Confirm Password"  onkeyup='check();' pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"  required> 
						</p>

						<input type="checkbox" onclick="myFunction()">  Show Password
						
						<button type="submit" class="submit-btn1" name="register_user" style="margin-top:15px; ">Register</button>
					</form>


				</div>

				<div style="color: white; background: black; font-size: 15px; width: 370px; margin: auto; padding: 10px; justify-content: none; align-content: none; white-space: pre-wrap;"><STRONG>NOTE: </STRONG> The password must contain at least:<br> 1)One number   2)One uppercase    3)Lowercase letter   4)Minimum 8 characters</div>

			</div>

		</div>
		
	</div>
</body>



<script type="text/javascript">


	var check = function() {
	  if (document.getElementById('password').value ==
	    document.getElementById('confirm_password').value) {
	    document.getElementById('confirm_password').style.border = '2px solid #81c644';
		document.getElementById('password').style.border = '2px solid #81c644';
	   
	  } else {
	     document.getElementById('confirm_password').style.border = '2px solid #b82121';
	     document.getElementById('password').style.border = '2px solid #b82121';
	  }
	}

	function myFunction() {
	  var x = document.getElementById("password");
	  var y = document.getElementById("confirm_password");
	  if (x.type === "password" && y.type === "password") {
	    x.type = "text";
	    y.type='text';
	  } else {
	    x.type = "password";
	    y.type= "password";
	  }
	}

</script>



<style>

*{
		padding: 0px;
		margin: 0px;
		}

body{
		background: rgb(190,128,252);
		background: linear-gradient(90deg, rgba(190,128,252,1) 0%, rgba(161,242,251,1) 40%, rgba(161,242,251,1) 60%, rgba(246,170,255,1) 100%);

		font-family: 'Playfair Display';

		}


.nav{
		font-size:50px;
		width:60px;
		margin-top: 0px;
		cursor:pointer; 
		color: black;
		left: 0px;
		position: absolute;

	}	

	.nav:hover{
		color: white;
		font-weight: 600;
		background:black;

	}

.toggle-btn1 > a{
  	text-decoration: none;
  	color: white
}

.block1{
	display: grid;
	grid-template-columns: 1fr;
	text-align: center;
	align-content: center;
	justify-content: center;
}


.sub1{
	font-family: serif;
	align-self: center;
}

.welcome1{
	font-size:80px;
	line-height: 2;
	margin-top: 50px;
	font-weight: 200;
	font-family: 'Playfair Display';


}

.form-box1{
	width: 370px;
	height: 470px;
	position: relative;
	margin: 6% auto;
	padding: 10px;
	background-color: black;
	margin: auto;
	margin-bottom: 30px;
	text-align: center;
	color:white;

}

.button-box1{
	width: 220px;
	margin: 35px auto;
	position: relative;
	box-shadow: 0 0 20px 9px #ff61241f;
	border-radius: 30px
}

.toggle-btn1{
	padding: 10px 30px;
	font-size: 15px;
	cursor: pointer;
	background-color: transparent;
	color: white;
	border:0;
	outline:none;
	position: relative;

}


#btn1{
	top:0;
	left: 0;
	position: absolute;
	width: 110px;
	height: 100%;
	background: linear-gradient(to right,#ff105f, #ffad06);
	border-radius: 30px;
	text-decoration-line:none;
	transition: 0.5s;

}



.form2{
	left: 50px;
	top: 125px;
	position: absolute;
	width: 280px;
	color: white;

}

.input-field1{
	width: 100%;
	padding: 10px 0;
	margin: 5px 0;
	border-left: 0;
	border-top: 0;
	border-right: 0;
	border-bottom: 1px solid #999;
	outline: none;
	background:transparent;
	color: white;

}


.submit-btn1{
	width: 85%;
	padding: 10px 30px;
	cursor: pointer;
	display: block;
	margin: auto;
	background: linear-gradient(to right,#ff105f, #ffad06);
	border:0;
	outline: none;

}

@media screen and (max-width: 900px){
	.welcome1{
		font-size: 40px;
	}

	
}

</style>

</html>