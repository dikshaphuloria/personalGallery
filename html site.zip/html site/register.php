<?php include('server.php'); ?>

<!DOCTYPE html>
<html>
<head>
	<title>~ Welcome ~</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="styles.css">
	
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

	<style type="text/css" >
		*{
			padding: 0px;
			margin: 0px;
		}

		body{
			background: rgb(0,0,0);
			background: linear-gradient(90deg, rgba(0,0,0,1) 0%, rgba(195,94,94,1) 25%, rgba(0,0,0,1) 50%, rgba(195,94,94,1) 75%, rgba(0,0,0,1) 100%);
			font-family: italic;

		}
	</style>


</head>
<body>

	<div class="container">
		
		<div id="myNav" class="overlay">
  			<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		  	<div class="overlay-content">
		    	<a href="index.html">HOME</a>
		    	<a href="about.html">ABOUT</a>
		    	<a href="feedback.html">FEEDBACK</a>
		    	<a href="#">Currently In Registering Process</a>
		  	</div>
		</div>
		<div class="nav" onclick="openNav()"> &#9776;OPEN</div>

     		

		<div class="block">
			
			<div class="sub1">

				<div class="welcome">  R E G I S T E R  </div>

				<div class="form-box">
					<div class="button-box">
						<div id="btn" style="left: 110px;"></div>
						<button type="button" class="toggle-btn" ><a href="login.php">Login</a></button>

						<button type="button" class="toggle-btn" >Register</button>

					</div>

					<form id="register" class="form2" action="register.php" method="post">
						<?php include('errors.php'); ?>

						<input type="text" class="input-field" name="username" placeholder="Username" required>

						<input type="email" class="input-field" name="email" placeholder="Email ID" required>

						<input type="password" class="input-field" name="password1" placeholder="Enter Password" required>

						<input type="password" class="input-field" name="password2" placeholder="Confirm Password" required>
						
						<button type="submit" class="submit-btn" name="register_user" style="margin-top:15px; ">Register</button>
					</form>


				</div>

			</div>
		

		</div>
		
	</div>
</body>

<script src="first.js"></script>

<style>
.nav{
		padding:10px; 
		font-size:30px;
		font-weight: 500;
		cursor:pointer; 
		color: white;
		background:black; 
		cursor: pointer;

	}

.toggle-btn > a{
  	text-decoration: none;
  	color: white
}
</style>

</html>