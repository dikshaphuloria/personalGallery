<?php

session_start();

//Initialising variables

$Username="";
$email="";
$errors= array();

//connect to db

$db = new mysqli('localhost', 'root', '','firstapp');

if ($db -> connect_errno) {
  echo "Failed to connect to MySQL: " . $db -> connect_error;
  exit();
}


//Register users
if(isset($_POST['register_user'])){
$Username = mysqli_real_escape_string($db, $_POST['Username']);
$email = mysqli_real_escape_string($db, $_POST['email']);
$password1 = mysqli_real_escape_string($db, $_POST['password1']);
$password2 = mysqli_real_escape_string($db, $_POST['password2']);

//form validation

if(empty($Username)){array_push($errors, "Username is required");}

if(empty($email)){array_push($errors, "Email is required");}

if(empty($password1)){array_push($errors, "Password is required");}

if($password1 != $password2){array_push($errors, "Password do not match");}


//check db for existing user with same username

$user_check_query = "SELECT * FROM user WHERE Username ='$Username' or email = '$email' LIMIT 1";

$result = mysqli_query($db, $user_check_query);
$user = mysqli_fetch_assoc($result);

if($user){ //if user exists

	if ($user['Username'] == $Username) {
		array_push($errors, "Username already exists");
	}

	if ($user['email'] == $email) {
		array_push($errors, "This email id is already registered");
	}

}


//Register the user if no error

if(count($errors)==0){

	$password = md5($password1);  //this will encrypt the password

	$query ="INSERT INTO user(Username,email,password) VALUES ('$Username','$email', '$password')";

	mysqli_query($db,$query);

	$_SESSION['Username'] = $Username;

	$_SESSION['success'] = "You are now logged In";

	header('location:index.php');

}

}



//Login User

if(isset($_POST['login_user'])){

	$Username = mysqli_real_escape_string($db, $_POST['Username']);
	$password = mysqli_real_escape_string($db, $_POST['password']);

	if(empty($Username)){

		array_push($errors, "Username is required");
	}

	if(empty($password)){

		array_push($errors, "Password is required");
	}

	if(count($errors)==0){

		$password = md5($password);

		$query = "SELECT * FROM user WHERE Username='$Username' AND password='$password' ";

		$results = mysqli_query($db, $query);

		if(mysqli_num_rows($results) == 1){

			$_SESSION['Username'] = $Username;
			$_SESSION['success'] = "Logged in successfully";

			header('location: index.php');
		}
		else{

			array_push($errors, "Invalid username/password.Try again!");
		}
	}

}

if(isset($_POST['feedback_form'])){

	$Username = mysqli_real_escape_string($db, $_POST['Username']);
	$password = mysqli_real_escape_string($db, $_POST['password']);

	if(empty($Username)){

		array_push($errors, "Username is required");
	}

	if(empty($password)){

		array_push($errors, "Password is required");
	}

	if(count($errors)==0){

		$password = md5($password);

		$query = "SELECT * FROM user WHERE Username='$Username' AND password='$password' ";

		$results = mysqli_query($db, $query);

		if(mysqli_num_rows($results) == 1){

			$_SESSION['Username'] = $Username;
			$_SESSION['success'] = "Logged in successfully";

			header('location: main.html');
		}
		else{

			array_push($errors, "Wrong username/password combination, Please try again.");
		}
	}

}



?>