<?php

//connect to db

$db = new mysqli('localhost', 'root', '','firstapp');

if ($db -> connect_errno) {
  echo "Failed to connect to MySQL: " . $db -> connect_error;
  exit();
}


?>