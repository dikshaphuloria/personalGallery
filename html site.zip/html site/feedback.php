<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>~Feed back~</title>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">
	<link rel="stylesheet" type="text/css" href="styles.css">


</head>
<body>
	
	<div class="container1">

		<div id="myNav" class="overlay">
  			<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		  	<div class="overlay-content">
		    	<a href="index.html">HOME</a>
		    	<a href="about.html">ABOUT</a> 
		    	<a href="feedback.php">Currently On Feed Back </a>
		  	</div>
		</div>
		<div class="nav" onclick="openNav()">OPEN</div>
     

		<div class="feedback">
		
			<h1>Every feedback response is valuable to us. Please proceed and fill the form mentioned below.</h1>
		
			<div>
				<h3 style="font-family: serif;">FEED BACK FORM</h3>

				<form class="form1" action="feedback.php" method="post">
					<?php include('server.php'); ?>
					<?php include('errors.php'); ?>

					<?php if(isset($_SESSION['success'])): ?>

							<div class="error success">
								<h3>
									<?php 

									echo $_SESSION['success'];
									unset($_SESSION['success']);

									?>
								</h3>
							</div>

					<?php endif?>



				 	
					<input type="text" name="first-name" placeholder="First Name"  required="">
					<p>
					
					<input type="text" name="last-name" placeholder="Last Name" required="">
					<p>

					<input type="email" name="email" placeholder="xyz@gmail.com" required="">
					<p>

					<div class="textarea">
						<textarea id="subject" name="comment" placeholder="Describe your experience.." required=""></textarea>
					</div>

					<br>

					<button class="btn1" name="feedback_form" type="Submit">Submit</button>
				</form>
			</div>
		</div>
	</div>


</body>

<script src="first.js"></script>

<style>
	.nav{
		background:black;
		padding:20px auto; 
		font-size:30px;
		font-weight: 700;
		cursor:pointer; 
		color: white;
		font-family: 'Playfair Display';

	}	

	.nav:hover{
		color: #097669;
	}

	
</style>

</html>