<?php

session_start();

if(!isset($_SESSION['Username'])){

	$_SESSION['msg'] = "You must log in to view this page";
	header('location: login.php');

}

if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION["Username"]);
	header("location: index.html");
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">

	<style>
		body{
			justify-content: center;
			align-content: center;
			text-align: center;
			align-items: center;
			font-family: Times;
			background:black;
		}


		.hello > a{
			padding: 5px;
			margin-bottom: 0px; 
			animation: pr 5s ease infinite alternate;
			font-family: sans;
			font-size: 30px;
			text-decoration: none;
			border: 1px solid transparent;
			box-shadow: 0 0 10px 5px pink;
		}


		@keyframes pr{
			from{color: black; background:white;}
			to {background: black; color: white;}
		 }

	</style>

</head>
<body>

	<?php if(isset($_SESSION['success'])): ?>

		<div class="error success">
			<h3>
				<?php 

				echo $_SESSION['success'];
				unset($_SESSION['success']);

				?>
			</h3>
		</div>

	<?php endif?>

<!-- logged in user information -->
<div style="background:white;" >

	<img src="images/picupload.png" style=" height: 500px; margin-top: 20px; border:20px solid white;">
</div>
<div class="hello">

	<a href="main.php" >Let's Proceed &#8594;</a>

</div>

</body>
</html>