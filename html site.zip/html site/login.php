<?php include('server.php'); ?>


<!DOCTYPE html>
<html>
<head>
	<title>~ LOGIN ~</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="styles.css">
	
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

	


</head>
<body>

	<div class="container">
		
		<div id="myNav" class="overlay">
  			<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		  	<div class="overlay-content">
		    	<a href="index.html">HOME</a>
		    	<a href="about.html">ABOUT</a>
		    	<a href="feedback.php">FEEDBACK</a>
		    	<a href="login.php">Currently IN Login Process</a>
		  	</div>
		</div>
		<div class="nav" onclick="openNav()"> OPEN</div>

     		

		<div class="block">
			
			<div class="sub1">

				<div class="welcome">   L O G I N  </div>

				<div class="form-box">
					<div class="button-box">
						<div id="btn"></div>
						<button type="button" class="toggle-btn" >Login</button>

						<button type="button" class="toggle-btn"><a href="register.php">Register</a></button>

					</div>

					<form id="login" class="form2" action="login.php" method="post">
						<?php include('errors.php'); ?>

						<input type="text" class="input-field" name="Username" placeholder="Username" required>

						<input type="password" class="input-field" name="password" placeholder="Enter Password" required>

						<button type="submit" class="submit-btn" name="login_user" style="margin-top: 50px;">Login</button>


						<h4 style="margin-top: 15px; font-weight: 200;">New User? Click on Register! </h4>
					</form>

				</div>

			</div>
		

		</div>
		
	</div>
</body>

<script src="first.js"></script>

<style>
.nav{
		background:black;
		padding:20px auto; 
		font-size:30px;
		font-weight: 700;
		cursor:pointer; 
		color: white;

	}	

	.nav:hover{
		color: #097669;
	}

.toggle-btn > a{
  	text-decoration: none;
  	color: white
}

</style>

</html>