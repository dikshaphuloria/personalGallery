<?php include('server.php'); ?>


<!DOCTYPE html>
<html>
<head>
	<title>~ LOGIN ~</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="styles.css">
	
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

	


</head>
<body>

	<div class="container">
		
		<div id="myNav" class="overlay">
  			<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		  	<div class="overlay-content">
		    	<a href="index.html">HOME</a>
		    	<a href="about.html">ABOUT</a>
		    	<a href="feedback.php">FEEDBACK</a>
		    	<a href="login.php">Currently IN Login Process</a>
		  	</div>
		</div>
		<div class="nav" onclick="openNav()"> &#8801;</div>

     		

		<div class="block">
			
			<div class="bat">
				<img src="images/pic2.jpg">
				<img src="images/pic3.jpg">
			</div>

			<div class="form-box">
					<div class="welcome">LOGIN</div>
			
					<form id="login" class="form2" action="login.php" method="post">
						<?php include('errors.php'); ?>

						<input type="text" class="input-field" name="Username" placeholder="Username" required>

						<input type="password" class="input-field" name="password" placeholder="Enter Password" required>

						<button type="submit" class="submit-btn" name="login_user" style="margin-top: 50px;">Login</button>


						<h4 style="margin-top: 15px; font-weight: 1000;">New User? Click on <a href="register.php">Register</a></h4>
					</form>

			</div>
		
		</div>
		
	</div>
</body>

<script src="first.js"></script>

<style>
	

body{
	background: rgb(0,0,0);
	background: linear-gradient(90deg, rgba(0,0,0,1) 50%, rgba(238,227,238,1) 50%);

	}


.nav{
		font-size:50px;
		width:60px;
		margin-top: 0px;
		cursor:pointer; 
		color: white;
		left: 0px;
		position: absolute;

	}	

	.nav:hover{
		color: black;
		font-weight: 600;
		background:white;

	}

h4 > a{
  	color: black;
  	cursor:pointer;
}

h4 > a:hover{
	background: white;
	color: black;
	text-decoration: none;
}

@media screen and (max-width: 900px){
	body{
		background: linear-gradient(0deg, rgba(238,227,238,1) 50%, rgba(0,0,0,1) 50%);
	}
}

</style>

</html>