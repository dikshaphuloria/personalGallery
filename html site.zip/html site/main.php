
<?php

session_start();

if(!isset($_SESSION['Username'])){

	$_SESSION['msg'] = "You must log in to view this page";
	header('location: login.php');

}

if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION["Username"]);
	header("location: index.html");
}


?>

<?php 
include('db.php');
$errors= array();
if(isset($_POST['upload'])){
	$user=$_SESSION["Username"];
	$newFileName = mysqli_real_escape_string($db, $_POST['filename']);
	$imageTitle = mysqli_real_escape_string($db, $_POST['filetitle']);
	$imageDesc = mysqli_real_escape_string($db, $_POST['filedesc']);
	$file = $_FILES['file'];

	if (empty($_POST['filename'])) {
		$newFileName ="gallery";
	}else{
		$newFileName =strtolower(str_replace("", "-", $newFileName));
	}


	$fileName =$file["name"];
	$fileType =$file["type"];
	$fileTempName =$file["tmp_name"];
	$fileError =$file["error"];
	$fileSize =$file["size"];


	$fileExt = explode('.',$fileName);
	$fileActualExt = strtolower(end($fileExt));

	$allowed = array("jpg","jpeg","png");

	if(in_array($fileActualExt, $allowed)){
		if ($fileError === 0) {

			if ($fileSize < 2000000) {
				$imageFullName = $newFileName.".".uniqid("",true).".".$fileActualExt;

				$fileDestination ="images/gallery/".$imageFullName;


				if (empty($imageTitle) || empty($imageDesc)) {
					header("Location:../main.php?upload=success");
					exit();
				}else{

							$query ="SELECT * FROM photoupload WHERE Username='$user'";
							$stmt = mysqli_query($db,$query);
							$rowCount = mysqli_num_rows($stmt);
							$setImageOrder= $rowCount + 1;

							$sql="INSERT INTO photoupload(filetitle,filedesc,fileImage,orderGallery,Username) VALUES ('$imageTitle', '$imageDesc', '$imageFullName', '$setImageOrder','$user')";

							mysqli_query($db,$sql);

							move_uploaded_file($fileTempName, $fileDestination);
							
							header("Location:main.php");			

						}

				
			}else{
				array_push($errors, "File size is too large!");
				exit();												
			}
			
		}else{
			array_push($errors, "An Error occured! Please try again.");
			exit();
		}
	}else{
		
		array_push($errors, "The file extension is not supported! You may try the following extension :jpg,png,jpeg");
		exit();
	}


}

?>





<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> ~ My Profile ~ </title>

	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">
	<link rel="stylesheet" type="text/css" href="styles.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

</head>
<body>

	<div class="container3" >
		
		<div id="myNav" class="overlay">
  			<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		  	<div class="overlay-content">
		    	<a href="main.php">In my gallery</a>
		    	<a href="contact.php">Contact Us</a>

		  	</div>
		</div>
		
		<div class="nav" onclick="openNav()">&#8801;</div>
		
		<?php if(isset($_SESSION['Username'])): ?>
		<h1 class="wel">Welcome to your personal gallery <?php echo $_SESSION['Username']; ?></h1>

		<button id="logout"><a href="index.php?logout='1'">&#9758;Logout</a></button>

		<?php endif?>

		<section class="gallery">

			<div class="gallery-wrap">
					<h2 style="text-align: center; font-size: 40px;">Gallery</h2>

				<div class="gallery-container">

						<?php
							$user=$_SESSION["Username"];
							$query="SELECT * FROM photoupload WHERE Username='$user' ORDER BY orderGallery DESC";
							$stmt = mysqli_query($db,$query);
							
							

							while ($row = mysqli_fetch_assoc($stmt)) {
									
								 echo '<a href="#">
									<div><img src="images/gallery/'.$row["fileImage"].'"></div>
									<h3>'.$row["filetitle"].'</h3>
									<p>'.$row["filedesc"].'</p>
									</a>';
								}
							

						?>

				</div>

			</div>
		</section>

		<?php
			
			if(isset($_SESSION["Username"])){
					include('errors.php');

				echo '<div class="gallery-upload">
					<h2 style="color:#eee867;">UPLOAD PICTURE</h2>
					<form action="main.php" method="post" enctype="multipart/form-data">
						<input type="text" name="filename" placeholder="File name...">
						<input type="text" name="filetitle" placeholder="Image title...">
						<input type="text" name="filedesc" placeholder="Image description...">
						<input type="file" name="file">

						<button class="upload" type="submit" name="upload">UPLOAD</button>
								
					</form>
				</div>';
			}
		?>

		

	</div>


	

</body>
<script src="first.js"></script>
<style>

	body{
		background: ghostwhite fixed 100%;
		justify-content: center;
		text-align: center;
		align-content: center;
		padding: 0px;
		margin: 0px;
		font-family: 'Playfair Display',italic, sans;
		box-sizing: border-box;	
		color: black;
		overflow-x: hidden;
	}

	a{
		text-decoration: none;
	}


	.nav{
		font-size:50px;
		width:60px;
		cursor:pointer; 
		color: black;
		left: 0px;

	}	

	.nav:hover{
		color: white;
		font-weight: 600;
		background:black;

	}


	#logout{
		padding: 2px;
		background: black;
		font-family: 'Playfair Display';
		font-size: 20px;
		position: absolute;
		border-radius: 20px;
		top:20px;
		right:10px;
		text-decoration: none;
		border: 1px solid transparent;
		}

	#logout:hover{
		background: white;
		border: 2px solid black;
	}	

	#logout> a{
		color: white;
	}

	#logout> a:hover{
		color: black;
	}




	.wel{
		font-family:'Tangerine'; 
		font-size: 70px; 
		justify-content: center; 
		text-align: center;
		color: #023f61;
		}


	

	@keyframes main{
    0% {box-shadow: 2px 2px 8px #04507C;}
    50% {box-shadow: 2px 2px 8px white;}
    70% {box-shadow: 2px 2px 8px pink;}
    100%{box-shadow: 2px 2px 8px red;}
}

</style>

</html>