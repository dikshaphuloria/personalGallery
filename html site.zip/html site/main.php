<?php

session_start();

if(!isset($_SESSION['Username'])){

	$_SESSION['msg'] = "You must log in to view this page";
	header('location: login.php');

}

if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION["Username"]);
	header("location: index.html");
}

?>



<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> ~ My Profile ~ </title>

	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">
	<link rel="stylesheet" type="text/css" href="styles.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

</head>
<body>

	<div class="container3" >
		
		<div id="myNav" class="overlay">
  			<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		  	<div class="overlay-content">
		    	<a href="main.php">In my gallery</a>
		    	<a href="contact.php">Contact Us</a>

		  	</div>
		</div>
		
		<div class="nav" onclick="openNav()">OPEN</div>
		
		<?php if(isset($_SESSION['Username'])): ?>
		<h1 class="wel">Welcome to your personal gallery <?php echo $_SESSION['Username']; ?></h1>

		<button id="logout"><a href="index.php?logout='1'">&#9758;Logout</a></button>

		<?php endif?>

		<section class="gallery">

			<div class="gallery-wrap">
					<h2 style="text-align: center; font-size: 40px;">Gallery</h2>

				<div class="gallery-container">


						<a href="#">
							<div></div>
							<h3>This is a title</h3>
							<p>This is a paragraph</p>
						</a>

						<a href="#">
							<div></div>
							<h3>This is a title</h3>
							<p>This is a paragraph</p>
						</a>

						<a href="#">
							<div></div>
							<h3>This is a title</h3>
							<p>This is a paragraph</p>
						</a>

					<a href="#">
						<div></div>
						<h3>This is a title</h3>
						<p>This is a paragraph</p>
					</a>
				</div>

			</div>
		</section>

		<div class="gallery-upload">
			<form action="server.php" method="post" enctype="multipart/form-data">
				<input type="text" name="filename" placeholder="File name...">
				<input type="text" name="filetitle" placeholder="Image title...">
				<input type="text" name="filedesc" placeholder="Image description...">
				<input type="file" name="file">

				<button type="submit" name="submit">UPLOAD</button>
						
			</form>
		</div>

	</div>


	

</body>
<script src="first.js"></script>
<style>


	.nav{
		background:black;
		padding:20px auto; 
		font-size:30px;
		font-weight: 700;
		cursor:pointer; 
		color: white;


	}	

	.nav:hover{
		color: #097669;
	}
	

	.logout{
		padding: 2px;
		animation: pr 5s ease infinite alternate;
		font-family: sans;
		font-size: 25px;
		position: absolute;
		top:0px;
		right:1px;
		text-decoration: none;
		border: 1px solid transparent;
		}

	.logout> a{
		animation: pr 5s ease infinite alternate;
	}

	.wel{
		font-family:'Tangerine'; 
		font-size: 70px; 
		justify-content: center; 
		text-align: center;
		color: #023f61;
		}

	.gallery-upload >form> button,input{
	display: block;
	line-height:2;
	padding: 2px;
	margin:20px auto;
	background:transparent;
	border:4px solid #eee867;
	border-radius: 15px;
}


	@keyframes pr{
		from{color: black; background:white;}
		to {color: white; background: #097669; }
		 }


	@keyframes main{
    0% {box-shadow: 2px 2px 8px #04507C;}
    50% {box-shadow: 2px 2px 8px white;}
    70% {box-shadow: 2px 2px 8px pink;}
    100%{box-shadow: 2px 2px 8px red;}
}

</style>

</html>